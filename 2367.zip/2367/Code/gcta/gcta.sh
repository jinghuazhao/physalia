# 24-4-2018 JHZ

gcta64 --bfile test --make-grm-bin --out test

